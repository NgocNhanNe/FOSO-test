import { NextResponse } from "next/server";
import { blogCards } from "@/foso/data";

export async function GET() {
  const categoryCount = blogCards.reduce(
    (acc, blog) => {
      acc[blog.category.name] = (acc[blog.category.name] || 0) + 1;
      return acc;
    },
    {} as Record<string, number>,
  );

  return NextResponse.json({
    categories: categoryCount,
  });
}
